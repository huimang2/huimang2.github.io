package com.example.demo;

import lombok.*;
import javax.persistence.*;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import java.util.Date;

@Getter
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@DynamicInsert
@DynamicUpdate

public class Board {
    
    @Id @GeneratedValue
    private Long seq;

    @Column(nullable = false)
    private String title;

    @Column(length = 40, nullable = false)
    private String writer;

    @Setter
    @Column(columnDefinition = "varchar(100) default 'No Contents'")
    private String content;

    @Temporal(TemporalType.DATE)
    @Column(updatable = false)
    private Date createDate;

    @ColumnDefault("0")
    private Long cnt;

    @PrePersist
	protected void onCreate() {
		createDate = new Date();
	}
}
