package com.example.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class JPAClient {

    public static void main(String[] args) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("practice");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {

            tx.begin();

            for(int i = 0; i < 10; i++) {
                Board board = Board.builder()
                .title("테이블 제목" + i)
                .writer("Rubisco")
                .content(i + "번째 글입니다.")
                .build();
            
                em.persist(board);
            }
            
            tx.commit();

            String jpql = "select b from Board b order by b.seq desc";
            List<Board> BoardList = em.createQuery(jpql, Board.class).getResultList();

            for(Board brd : BoardList) {
                System.out.println("---> " + brd.getTitle());
            }

        } catch (Exception e) {
            e.printStackTrace();
            tx.rollback();
        } finally {
            em.close();
            emf.close();
        }
    }
}
