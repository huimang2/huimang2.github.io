package kro.rubisco.service;

import java.util.List;

import kro.rubisco.dto.CommentDTO;

public interface CommentService {

	  public void regist(CommentDTO comment) throws Exception;

	  public CommentDTO read(Long commentId) throws Exception;

	  public void modify(CommentDTO comment) throws Exception;

	  public void remove(Long commentId) throws Exception;

	  public List<CommentDTO> listAll() throws Exception;
}
