package kro.rubisco.service;

import java.util.List;

import kro.rubisco.dto.BoardDTO;

public interface BoardService {

	  public void regist(BoardDTO board) throws Exception;

	  public BoardDTO read(Long documentId) throws Exception;

	  public void modify(BoardDTO board) throws Exception;

	  public void remove(Long documentId) throws Exception;

	  public List<BoardDTO> listAll() throws Exception;
}
