package kro.rubisco.dao;

import java.util.List;

import kro.rubisco.dto.BoardDTO;
import kro.rubisco.dto.PageDTO;

public interface BoardDAO {
	
	public void create(BoardDTO board) throws Exception;
	
	public BoardDTO read(Long documentId) throws Exception;

	public void update(BoardDTO board) throws Exception;

	public void delete(Long documentId) throws Exception;

	public List<BoardDTO> listAll(PageDTO<BoardDTO> boardPage) throws Exception;
	
	public long getCount() throws Exception;
}
