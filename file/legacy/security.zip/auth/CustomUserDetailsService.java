package kro.rubisco.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import kro.rubisco.dto.MemberDTO;
import kro.rubisco.service.MemberService;
import lombok.Setter;

public class CustomUserDetailsService implements UserDetailsService {

    @Setter(onMethod_ = @Autowired)
    private MemberService memberService;
    
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        try {
            MemberDTO member = memberService.read(email);
            return member == null ? null : new CustomUser(member);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } 
    }
}
