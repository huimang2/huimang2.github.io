package kro.rubisco.service.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kro.rubisco.dao.MemberDAO;
import kro.rubisco.dto.LoginDTO;
import kro.rubisco.dto.MemberDTO;
import kro.rubisco.service.MemberService;

@Service
@Transactional(readOnly = true)
public class MemberServiceImpl implements MemberService {

	private final MemberDAO memberDAO;
	private final PasswordEncoder bcryptPasswordEncoder;

	public MemberServiceImpl(SqlSession sqlSession, PasswordEncoder bcryptPasswordEncoder) {
		this.memberDAO = sqlSession.getMapper(MemberDAO.class);
		this.bcryptPasswordEncoder = bcryptPasswordEncoder;
	}
	
	@Override
	public void regist(MemberDTO member) throws Exception {
	    member.setPassword(bcryptPasswordEncoder.encode(member.getPassword()));
		memberDAO.create(member);
	}

	@Override
	public MemberDTO read(Long memberId) throws Exception {
		return memberDAO.read(memberId);
	}
	
	@Override
    public MemberDTO read(String email) throws Exception {
        return memberDAO.getMemberByEmail(email);
    }

	@Override
	public void modify(MemberDTO member) throws Exception {
		memberDAO.update(member);
	}

	@Override
	public void remove(Long memberId) throws Exception {
		memberDAO.delete(memberId);
	}

	@Override
	public List<MemberDTO> listAll() throws Exception {
		return memberDAO.listAll();
	}

    @Override
    public MemberDTO login(LoginDTO loginForm) throws Exception {
        return memberDAO.login(loginForm);
    }

}
