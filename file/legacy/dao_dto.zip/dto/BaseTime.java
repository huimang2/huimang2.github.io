package kro.rubisco.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseTime {
	private Date createDate;
	private Date updateDate;
}
