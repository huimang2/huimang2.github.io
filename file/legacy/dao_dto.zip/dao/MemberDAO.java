package kro.rubisco.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kro.rubisco.dto.MemberDTO;

@Mapper
public interface MemberDAO {

	public void create(MemberDTO member) throws Exception;
	
	public MemberDTO read(Long memberId) throws Exception;

	public void update(MemberDTO member) throws Exception;

	public void delete(Long memberId) throws Exception;

	public List<MemberDTO> listAll() throws Exception;
}
