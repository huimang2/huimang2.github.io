export class MainScene extends Phaser.Scene {

    constructor() {
        super({ key: 'main', active: true })
    }

    preload(): void {
        this.load.image('sky', 'assets/image/sky.png');
        this.load.image('ground', 'assets/image/platform.png');
        this.load.image('star', 'assets/image/star.png');
        this.load.image('bomb', 'assets/image/bomb.png');
        this.load.spritesheet('dude', 
            'assets/image/dude.png',
            { frameWidth: 32, frameHeight: 48 }
        );
    }

    create(): void {

        this.add.image(400, 300, 'sky');

        const platforms = this.physics.add.staticGroup();

        platforms.create(400, 568, 'ground').setScale(2).refreshBody();

        platforms.create(600, 400, 'ground');
        platforms.create(50, 250, 'ground');
        platforms.create(750, 220, 'ground');

        const player = this.physics.add.sprite(100, 450, 'dude').setName("player");

        player.setBounce(0.2);
        player.setCollideWorldBounds(true);

        this.anims.create({
            key: 'left',
            frames: this.anims.generateFrameNumbers('dude', { start: 0, end: 3 }),
            frameRate: 10,
            repeat: -1
        });

        this.anims.create({
            key: 'turn',
            frames: [ { key: 'dude', frame: 4 } ],
            frameRate: 20
        });

        this.anims.create({
            key: 'right',
            frames: this.anims.generateFrameNumbers('dude', { start: 5, end: 8 }),
            frameRate: 10,
            repeat: -1
        });

        this.physics.add.collider(player, platforms);

        let stars = this.physics.add.group({
            key: 'star',
            repeat: 11,
            setXY: { x: 12, y: 0, stepX: 70 }
        });

        this.data.set("stars", stars);
        
        stars.children.iterate(function (child) {
            (child as Phaser.Physics.Arcade.Image).setBounceY(Phaser.Math.FloatBetween(0.4, 0.8));
        });

        this.physics.add.collider(stars, platforms);
        this.physics.add.overlap(player, stars, this.collectStar, undefined, this);

        this.data.set("score", 0);
        this.add.text(16, 16, 'score: 0', { fontSize: '32px', color: '#000' }).setName("scoreText");

        const bombs = this.physics.add.group();

        this.data.set("bombs", bombs);
        this.physics.add.collider(bombs, platforms);
        this.physics.add.collider(player, bombs, this.hitBomb, undefined, this);

    }

    collectStar (player: Phaser.Types.Physics.Arcade.GameObjectWithBody, star: Phaser.Types.Physics.Arcade.GameObjectWithBody): void {
        (star as Phaser.Physics.Arcade.Image).disableBody(true, true);
        this.data.set("score", this.data.get("score") as number + 10);
        (this.children.getByName("scoreText") as Phaser.GameObjects.Text).setText('Score: ' + (this.data.get("score") as number));

        const stars = this.data.get("stars") as Phaser.Physics.Arcade.Group;

        if (stars.countActive(true) === 0) {
            stars.children.iterate(function (child) {
                (child as Phaser.Physics.Arcade.Image).enableBody(true, (child as Phaser.Physics.Arcade.Image).x, 0, true, true);
            });

            const x = ((player as Phaser.Types.Physics.Arcade.SpriteWithDynamicBody).x < 400) ? Phaser.Math.Between(400, 800) : Phaser.Math.Between(0, 400);
            const bombs = this.data.get("bombs") as Phaser.Physics.Arcade.Group;
            const bomb = bombs.create(x, 16, 'bomb');

            bomb.setBounce(1);
            bomb.setCollideWorldBounds(true);
            bomb.setVelocity(Phaser.Math.Between(-200, 200), 20);
        }
    }

    hitBomb (player: Phaser.Types.Physics.Arcade.GameObjectWithBody, _bomb: Phaser.Types.Physics.Arcade.GameObjectWithBody): void {
        this.physics.pause();
        (player as Phaser.Types.Physics.Arcade.SpriteWithDynamicBody).setTint(0xff0000);
        (player as Phaser.Types.Physics.Arcade.SpriteWithDynamicBody).anims.play('turn');
    }

    update(_time: number, _delta: number): void {

        const cursors = this.input.keyboard.createCursorKeys();
        const player = this.children.getByName("player") as Phaser.Types.Physics.Arcade.SpriteWithDynamicBody;

        if (cursors.left.isDown)
        {
            player.setVelocityX(-160);

            player.anims.play('left', true);
        }
        else if (cursors.right.isDown)
        {
            player.setVelocityX(160);

            player.anims.play('right', true);
        }
        else
        {
            player.setVelocityX(0);

            player.anims.play('turn');
        }

        if (cursors.up.isDown && player.body.touching.down)
        {
            player.setVelocityY(-330);
        }
    }

    destroy(): void {
    }
}